/* Stilllegung der Testversion: räumt nur die Test-Caches auf, meldet sich ab und leitet auf die Hauptversion */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil((async () => {
  const ks = await caches.keys();
  await Promise.all(ks.filter((k) => k.startsWith('burnicu-v3-test')).map((k) => caches.delete(k)));
  await self.registration.unregister();
  const cl = await self.clients.matchAll({ type: 'window' });
  cl.forEach((c) => c.navigate('../'));
})()));
